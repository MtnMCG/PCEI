Place pcei_750m_competitive_best.pt here, or simply launch the app and it will automatically download pcei_750m_competitive_best.pt from Hugging Face (MtnMCG/PCEI-Text).
