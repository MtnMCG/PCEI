Place pcei_750m_competitive_best.pt here, or just launch the app: it auto-downloads it from Hugging Face (MtnMCG/PCEI-Text).
