PCEI 750M Weights Placeholder.
When launched, chat.py auto-downloads pcei_750m_competitive_best.pt from Hugging Face if missing.
